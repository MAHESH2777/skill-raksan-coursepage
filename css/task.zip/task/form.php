 <div class="container">
<div class="col-25"></div>
<div class="col-50">

<form action="" method="post">
    <div class="row">
            <h3>Register Now</h3>
    <div class="col-25"></div>
      <div class="col-75">
        <input type="text" id="fname" name="name" placeholder="Name">
      </div>
    </div>
    <div class="row">
    <div class="col-25"></div>
      <div class="col-75">
        <input type="text" id="lname" name="number" placeholder="Number">
      </div>
    </div>
    <div class="row">
    <div class="col-25"></div>
        <div class="col-75">
          <input type="text" id="lname" name="email" placeholder="Email">
        </div>
      </div>
      <div class="col-25"></div>
        <div class="col-75">
          <input type="text" id="lname" name="city" placeholder="City">
        </div>
      </div>
    <div class="row">
  
    <br>
    <div class="row">
            <div class="col-25">
         
                  </div>
                  <div class="col-50">
                  <input  type="submit" value="Submit" name="submit">
                      </div>
                      <div class="col-25">
                    
                          </div>
    </div>
    </form>
</div>
<div class="col-25"></div>
   
  </div>