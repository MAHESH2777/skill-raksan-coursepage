
<form action="" method="post">
            <h3>Register Now</h3>

        <input type="text" id="fname" name="name" placeholder="Name" required="">

        <input type="text" id="num" name="number" placeholder="Number" required="">


          <input type="text" id="email" name="email" placeholder="Email" required="">
        
          <input type="text" id="city" name="city" placeholder="City" required="">
        
          <input type="text" class="one two three four five six seven eight disable"  id="course" name="course" placeholder="course" required="" disabled>
          <input type="hidden" class="one two three four five six seven eight disable"  id="course" name="course" placeholder="course" required="" >
 
                  <input  type="submit" value="Submit" name="submit">            
    </form>

